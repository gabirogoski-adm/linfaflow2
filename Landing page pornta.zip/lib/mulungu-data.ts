export interface KitOffer {
  id: string
  tag: string
  tagClass: string
  title: string
  subtitle: string
  qty: string
  bottles: number
  image: string
  oldPrice: string
  newPrice: string
  bonusGift?: string
  url: string
  headline: string
  subhead: string
  freeBadge?: string
  perks: string[]
}

const CDN = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files"

export function cdnImg(url: string, width: number) {
  if (!url.includes("cdn.shopify.com/s/files")) return url
  return `${url}${url.includes("?") ? "&" : "?"}width=${width}`
}

export const KITS: KitOffer[] = [
  {
    id: "kit-1",
    tag: "Para Testar",
    tagClass: "tag-teal",
    title: "1 Unidade",
    subtitle: "Tratamento de 30 dias",
    qty: "1x",
    bottles: 1,
    image: `${CDN}/1_unidade.png?v=1793232697`,
    oldPrice: "R$ 297,00",
    newPrice: "R$ 109,90",
    url: "https://pedido.extratobotanico.com.br/pay/826cbfac-1ac6-4466-a701-6d52482f37e1",
    headline: "1 Unidade",
    subhead: "Unidade avulsa",
    perks: ["30 dias de noites tranquilas", "Envio rastreado", "Garantia de 180 dias"],
  },
  {
    id: "kit-2",
    tag: "Tratamento recomendado",
    tagClass: "tag-green",
    title: "Compre 1 leve 2",
    subtitle: "Tratamento Recomendado · 60 dias",
    qty: "2x",
    bottles: 2,
    image: `${CDN}/1_unidade.png?v=1793232697`,
    oldPrice: "R$ 497,00",
    newPrice: "R$ 169,90",
    bonusGift: "Frete grátis",
    url: "https://pedido.extratobotanico.com.br/pay/7a76feff-05ef-41fb-ad48-27f9f9f49d58",
    headline: "Leve 2",
    subhead: "Compre 1, leve 2",
    freeBadge: "1 grátis",
    perks: ["60 dias de noites tranquilas", "Envio rastreado e grátis", "Garantia de 180 dias"],
  },
  {
    id: "kit-3",
    tag: "Máximo Desconto",
    tagClass: "tag-teal",
    title: "Compre 2 leve 4",
    subtitle: "Protocolo Completo 120 dias",
    qty: "4x",
    bottles: 4,
    image: `${CDN}/compre_2_leve_mais_2.png?v=1793232697`,
    oldPrice: "R$ 897,00",
    newPrice: "R$ 249,90",
    bonusGift: "Frete grátis",
    url: "https://pedido.extratobotanico.com.br/pay/ecc7c241-77fc-4410-b629-fd1161bbedd4",
    headline: "Leve 4",
    subhead: "Compre 2, leve 4",
    freeBadge: "2 grátis",
    perks: ["120 dias de noites tranquilas", "Envio rastreado e grátis", "Garantia de 180 dias"],
  },
]

export const GALLERY_SLIDES = [
  { src: `${CDN}/Imagem_principal_3ae2e2df-8b0b-41d9-bdda-163aa93e2e5d.png?v=1793232698`, alt: "Mulungu Silvestre Puro - 60 cápsulas softgel" },
  { src: `${CDN}/Beneficios.png?v=1793232698`, alt: "Benefícios do Mulungu Silvestre Puro" },
  { src: `${CDN}/Imagem_composicao.png?v=1793232697`, alt: "Composição: o que tem por dentro do Mulungu" },
  { src: `${CDN}/Imagem_final_Mulungu.png?v=1793232699`, alt: "Mulungu Silvestre Puro - extrato botânico" },
]

export const SYMPTOMS = [
  { id: 1, name: "Deito cansada, mas a mente não desliga" },
  { id: 2, name: "Acordo de madrugada e não volto a dormir" },
  { id: 3, name: "Sinto aperto no peito ou falta de ar do nada" },
  { id: 4, name: "Coração dispara sem motivo aparente" },
  { id: 5, name: "Acordo mais cansada do que deitei" },
  { id: 6, name: "Ombros travados e mandíbula sempre tensa" },
  { id: 7, name: "Me preocupo demais com tudo e com todos" },
  { id: 8, name: "Choro fácil ou fico irritada à toa" },
]

export const COMPOUNDS = [
  {
    img: "/images/comp-melatonina.webp",
    name: "Melatonina",
    text: "Indutor do sono: avisa o corpo que é hora de dormir.",
  },
  {
    img: "/images/comp-magnesio.webp",
    name: "Magnésio",
    text: "Para diminuir a ansiedade e a tensão muscular.",
  },
  {
    img: "/images/comp-triptofano.webp",
    name: "Triptofano",
    text: "Induz o relaxamento na hora de deitar.",
  },
  {
    img: "/images/comp-b6.webp",
    name: "Vitamina B6",
    text: "Ajuda a controlar e regular o seu sono.",
  },
  {
    img: "/images/comp-mulungu.webp",
    name: "Extrato de Mulungu",
    text: "Extrato da planta Mulungu, com alcaloides e flavonoides naturais que acalmam a mente e o corpo.",
  },
]

export const WHATSAPP_TESTIMONIALS = [
  {
    id: "wa-1",
    name: "Sônia Ribeiro",
    initials: "SR",
    city: "Belo Horizonte",
    state: "MG",
    time: "09:14",
    mediaUrl: "/images/wa-1.webp",
    mediaCaption: "📦 Meu Mulungu chegou em 3 dias!",
    message:
      "Chegou certinho, embalagem discreta. Tomei ontem à noite e pela primeira vez em MESES dormi direto até as 6h. Não acreditei! 🙏😭",
    supportReply: "Que alegria, Sônia! 🥰 Tome sempre 1 hora antes de deitar e mantenha a constância. O melhor ainda está por vir!",
    reactions: ["❤️", "🙏"],
  },
  {
    id: "wa-2",
    name: "Cláudia Matos",
    initials: "CM",
    city: "Curitiba",
    state: "PR",
    time: "22:47",
    mediaUrl: "/images/wa-2.webp",
    mediaCaption: "🌙 Meu ritual da noite agora",
    message:
      "Eu acordava 3h da manhã com o coração disparado TODA noite. Já são 12 dias sem isso. Aquele aperto no peito sumiu. Tô até mais paciente com meu marido 😂",
    supportReply: "Isso é o Mulungu acalmando o seu sistema nervoso, Cláudia! Ficamos muito felizes 💚",
    reactions: ["😍", "👏"],
  },
  {
    id: "wa-3",
    name: "Marlene Duarte",
    initials: "MD",
    city: "Recife",
    state: "PE",
    time: "07:32",
    mediaUrl: "/images/wa-3.webp",
    mediaCaption: "☀️ Bom dia descansada, gente!",
    message:
      "Tomava remédio tarja preta há 4 anos e acordava parecendo zumbi. Com o Mulungu eu durmo e acordo DISPOSTA, sem ressaca nenhuma. Já pedi o kit de 4!",
    reactions: ["❤️", "🔥"],
  },
]

const PROOF_BASE = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files"
export const PROOF_IMAGES = [
  `${PROOF_BASE}/Imagem_carrossel_12.jpg?v=1793232689`,
  `${PROOF_BASE}/Imagem_carrossel_10.png?v=1793232698`,
  `${PROOF_BASE}/Imagem_carrossel_5.png?v=1793232699`,
  `${PROOF_BASE}/Imagem_carrossel_1.png?v=1793232698`,
  `${PROOF_BASE}/Imagem_carrossel_11.png?v=1793232698`,
  `${PROOF_BASE}/Imagem_carrossel_4.png?v=1793232699`,
  `${PROOF_BASE}/Imagem_carrossel_2.png?v=1793232698`,
  `${PROOF_BASE}/Imagem_carrossel_8.png?v=1793232699`,
  `${PROOF_BASE}/Imagem_carrossel_7.png?v=1793232699`,
  `${PROOF_BASE}/Imagem_carrossel_9.png?v=1793232699`,
  `${PROOF_BASE}/Imagem_carrossel_6.png?v=1793232698`,
  `${PROOF_BASE}/Imagem_carrossel_3.png?v=1793232699`,
]

export const REVIEWS = [
  {
    initials: "VL",
    name: "Vera Lúcia M., 57 anos",
    text: "Eu passava a noite inteira pensando em problema, virando de um lado pro outro. Na primeira semana com o Mulungu já consegui dormir 7 horas seguidas. Minha vida mudou.",
    date: "21 de outubro de 2026",
  },
  {
    initials: "RA",
    name: "Rosângela A., 52 anos",
    text: "O aperto no peito era tão forte que fui duas vezes ao pronto-socorro achando que era o coração. Era ansiedade. Hoje respiro aliviada, literalmente.",
    date: "14 de outubro de 2026",
  },
  {
    initials: "TC",
    name: "Tereza C., 63 anos",
    text: "Tinha medo de virar dependente de remédio. O Mulungu é natural e me deixou calma sem me deixar dopada. Acordo leve e com vontade de fazer as coisas.",
    date: "02 de outubro de 2026",
  },
  {
    initials: "EF",
    name: "Eliane F., 49 anos",
    text: "Minha mandíbula vivia travada, os ombros duros. Depois de 15 dias senti o corpo soltar. Comprei o kit de 4 para fazer o tratamento completo.",
    date: "27 de setembro de 2026",
  },
  {
    initials: "MN",
    name: "Márcia N., 55 anos",
    text: "Achei que a história da bênção era só marketing, mas o produto é sério. Chegou rápido, bem embalado, e o efeito no meu sono foi impressionante.",
    date: "19 de setembro de 2026",
  },
  {
    initials: "IG",
    name: "Ivone G., 60 anos",
    text: "Minha filha me deu de presente. Eu era a pessoa mais preocupada da família, chorava por tudo. Hoje estou mais leve, mais serena. Obrigada!",
    date: "08 de setembro de 2026",
  },
]

export const FAQS = [
  { question: "Como recebo o produto?", answer: "Envio rastreado para todo o Brasil, com prazo de 2 a 5 dias úteis. Você recebe o código de rastreio por e-mail e WhatsApp." },
  { question: "Vou ser cobrado de novo?", answer: "Não. É uma compra única, sem assinatura e sem cobranças escondidas." },
  { question: "O pagamento é seguro?", answer: "Sim. Nosso checkout é 100% encriptado com certificado SSL. Aceitamos Pix, cartão de crédito e boleto." },
  { question: "E se não funcionar pra mim?", answer: "Você tem garantia total de 180 dias. Se não ficar satisfeita, devolvemos 100% do seu dinheiro, sem perguntas." },
  { question: "Como devo tomar o Mulungu Silvestre Puro?", answer: "Tome 2 cápsulas softgel ao dia, de preferência 1 hora antes de dormir, com um copo de água. Para ansiedade durante o dia, pode dividir: 1 pela manhã e 1 à noite." },
  { question: "Causa dependência ou sonolência no dia seguinte?", answer: "Não. Por ser uma fórmula 100% natural, o Mulungu age em harmonia com o organismo. Não vicia, não gera tolerância e não causa efeito ressaca ao acordar." },
  { question: "Em quanto tempo vou sentir os resultados?", answer: "Muitas clientes relatam noites mais tranquilas já na primeira semana. Para resultados profundos e duradouros, recomendamos o tratamento de 120 a 180 dias." },
  { question: "Posso tomar se uso outros medicamentos?", answer: "Se você faz uso de medicamentos controlados, está grávida ou amamentando, consulte seu médico antes de iniciar qualquer suplemento." },
]

export const CITIES = [
  { city: "São Paulo", state: "SP" },
  { city: "Belo Horizonte", state: "MG" },
  { city: "Salvador", state: "BA" },
  { city: "Curitiba", state: "PR" },
  { city: "Fortaleza", state: "CE" },
  { city: "Goiânia", state: "GO" },
  { city: "Porto Alegre", state: "RS" },
  { city: "Recife", state: "PE" },
  { city: "Campinas", state: "SP" },
  { city: "Florianópolis", state: "SC" },
]

export const BUYER_NAMES = ["Maria José", "Lúcia", "Aparecida", "Regina", "Sandra", "Fátima", "Rosa", "Célia", "Vânia", "Neide"]
