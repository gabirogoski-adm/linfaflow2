import type { MouseEvent } from "react"

export function scrollToOffers(e?: MouseEvent) {
  e?.preventDefault()
  const target =
    document.getElementById("escolha-seu-kit") ||
    document.getElementById("escolha-protocolo") ||
    document.getElementById("offers")
  if (!target) return
  const header = document.querySelector("header")
  const headerHeight = header ? header.getBoundingClientRect().height : 60
  const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 10
  window.scrollTo({ top: Math.max(0, top), behavior: "smooth" })
}
