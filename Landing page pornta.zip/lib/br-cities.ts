export type ToastCity = { city: string; state: string }

type GeoCity = ToastCity & { lat: number; lng: number }

const BR_CITIES: GeoCity[] = [
  { city: "São Paulo", state: "SP", lat: -23.55, lng: -46.63 },
  { city: "Guarulhos", state: "SP", lat: -23.46, lng: -46.53 },
  { city: "Osasco", state: "SP", lat: -23.53, lng: -46.79 },
  { city: "Santo André", state: "SP", lat: -23.66, lng: -46.53 },
  { city: "São Bernardo do Campo", state: "SP", lat: -23.69, lng: -46.56 },
  { city: "Mogi das Cruzes", state: "SP", lat: -23.52, lng: -46.19 },
  { city: "Jundiaí", state: "SP", lat: -23.19, lng: -46.88 },
  { city: "Campinas", state: "SP", lat: -22.91, lng: -47.06 },
  { city: "Piracicaba", state: "SP", lat: -22.73, lng: -47.65 },
  { city: "Limeira", state: "SP", lat: -22.56, lng: -47.4 },
  { city: "Sorocaba", state: "SP", lat: -23.5, lng: -47.46 },
  { city: "Santos", state: "SP", lat: -23.96, lng: -46.33 },
  { city: "São José dos Campos", state: "SP", lat: -23.18, lng: -45.89 },
  { city: "Taubaté", state: "SP", lat: -23.03, lng: -45.56 },
  { city: "Ribeirão Preto", state: "SP", lat: -21.18, lng: -47.81 },
  { city: "Franca", state: "SP", lat: -20.54, lng: -47.4 },
  { city: "São Carlos", state: "SP", lat: -22.02, lng: -47.89 },
  { city: "Araraquara", state: "SP", lat: -21.79, lng: -48.18 },
  { city: "Bauru", state: "SP", lat: -22.31, lng: -49.06 },
  { city: "Marília", state: "SP", lat: -22.21, lng: -49.95 },
  { city: "São José do Rio Preto", state: "SP", lat: -20.82, lng: -49.38 },
  { city: "Presidente Prudente", state: "SP", lat: -22.12, lng: -51.39 },
  { city: "Rio de Janeiro", state: "RJ", lat: -22.91, lng: -43.17 },
  { city: "Niterói", state: "RJ", lat: -22.88, lng: -43.1 },
  { city: "Duque de Caxias", state: "RJ", lat: -22.79, lng: -43.31 },
  { city: "Nova Iguaçu", state: "RJ", lat: -22.76, lng: -43.45 },
  { city: "Petrópolis", state: "RJ", lat: -22.5, lng: -43.18 },
  { city: "Volta Redonda", state: "RJ", lat: -22.52, lng: -44.1 },
  { city: "Campos dos Goytacazes", state: "RJ", lat: -21.75, lng: -41.32 },
  { city: "Macaé", state: "RJ", lat: -22.37, lng: -41.78 },
  { city: "Belo Horizonte", state: "MG", lat: -19.92, lng: -43.94 },
  { city: "Contagem", state: "MG", lat: -19.93, lng: -44.05 },
  { city: "Betim", state: "MG", lat: -19.97, lng: -44.2 },
  { city: "Sete Lagoas", state: "MG", lat: -19.46, lng: -44.25 },
  { city: "Divinópolis", state: "MG", lat: -20.14, lng: -44.88 },
  { city: "Ipatinga", state: "MG", lat: -19.47, lng: -42.54 },
  { city: "Governador Valadares", state: "MG", lat: -18.85, lng: -41.95 },
  { city: "Juiz de Fora", state: "MG", lat: -21.76, lng: -43.35 },
  { city: "Uberlândia", state: "MG", lat: -18.92, lng: -48.28 },
  { city: "Uberaba", state: "MG", lat: -19.75, lng: -47.93 },
  { city: "Montes Claros", state: "MG", lat: -16.73, lng: -43.86 },
  { city: "Poços de Caldas", state: "MG", lat: -21.79, lng: -46.56 },
  { city: "Varginha", state: "MG", lat: -21.55, lng: -45.43 },
  { city: "Vitória", state: "ES", lat: -20.32, lng: -40.34 },
  { city: "Vila Velha", state: "ES", lat: -20.33, lng: -40.29 },
  { city: "Serra", state: "ES", lat: -20.13, lng: -40.31 },
  { city: "Cachoeiro de Itapemirim", state: "ES", lat: -20.85, lng: -41.11 },
  { city: "Curitiba", state: "PR", lat: -25.43, lng: -49.27 },
  { city: "São José dos Pinhais", state: "PR", lat: -25.53, lng: -49.21 },
  { city: "Ponta Grossa", state: "PR", lat: -25.09, lng: -50.16 },
  { city: "Londrina", state: "PR", lat: -23.31, lng: -51.16 },
  { city: "Maringá", state: "PR", lat: -23.42, lng: -51.94 },
  { city: "Cascavel", state: "PR", lat: -24.96, lng: -53.46 },
  { city: "Foz do Iguaçu", state: "PR", lat: -25.55, lng: -54.59 },
  { city: "Guarapuava", state: "PR", lat: -25.39, lng: -51.46 },
  { city: "Florianópolis", state: "SC", lat: -27.6, lng: -48.55 },
  { city: "São José", state: "SC", lat: -27.61, lng: -48.63 },
  { city: "Joinville", state: "SC", lat: -26.3, lng: -48.85 },
  { city: "Blumenau", state: "SC", lat: -26.92, lng: -49.07 },
  { city: "Itajaí", state: "SC", lat: -26.91, lng: -48.66 },
  { city: "Balneário Camboriú", state: "SC", lat: -26.99, lng: -48.63 },
  { city: "Criciúma", state: "SC", lat: -28.68, lng: -49.37 },
  { city: "Lages", state: "SC", lat: -27.82, lng: -50.33 },
  { city: "Chapecó", state: "SC", lat: -27.1, lng: -52.62 },
  { city: "Porto Alegre", state: "RS", lat: -30.03, lng: -51.23 },
  { city: "Canoas", state: "RS", lat: -29.92, lng: -51.18 },
  { city: "Novo Hamburgo", state: "RS", lat: -29.68, lng: -51.13 },
  { city: "São Leopoldo", state: "RS", lat: -29.76, lng: -51.15 },
  { city: "Gravataí", state: "RS", lat: -29.94, lng: -50.99 },
  { city: "Caxias do Sul", state: "RS", lat: -29.17, lng: -51.18 },
  { city: "Santa Maria", state: "RS", lat: -29.69, lng: -53.81 },
  { city: "Pelotas", state: "RS", lat: -31.77, lng: -52.34 },
  { city: "Passo Fundo", state: "RS", lat: -28.26, lng: -52.41 },
  { city: "Brasília", state: "DF", lat: -15.79, lng: -47.88 },
  { city: "Taguatinga", state: "DF", lat: -15.83, lng: -48.06 },
  { city: "Goiânia", state: "GO", lat: -16.69, lng: -49.26 },
  { city: "Aparecida de Goiânia", state: "GO", lat: -16.82, lng: -49.24 },
  { city: "Anápolis", state: "GO", lat: -16.33, lng: -48.95 },
  { city: "Rio Verde", state: "GO", lat: -17.8, lng: -50.93 },
  { city: "Campo Grande", state: "MS", lat: -20.47, lng: -54.62 },
  { city: "Dourados", state: "MS", lat: -22.22, lng: -54.81 },
  { city: "Cuiabá", state: "MT", lat: -15.6, lng: -56.1 },
  { city: "Várzea Grande", state: "MT", lat: -15.65, lng: -56.13 },
  { city: "Rondonópolis", state: "MT", lat: -16.47, lng: -54.64 },
  { city: "Salvador", state: "BA", lat: -12.97, lng: -38.5 },
  { city: "Lauro de Freitas", state: "BA", lat: -12.89, lng: -38.33 },
  { city: "Camaçari", state: "BA", lat: -12.7, lng: -38.32 },
  { city: "Feira de Santana", state: "BA", lat: -12.27, lng: -38.97 },
  { city: "Vitória da Conquista", state: "BA", lat: -14.86, lng: -40.84 },
  { city: "Ilhéus", state: "BA", lat: -14.79, lng: -39.05 },
  { city: "Itabuna", state: "BA", lat: -14.79, lng: -39.28 },
  { city: "Juazeiro", state: "BA", lat: -9.41, lng: -40.5 },
  { city: "Aracaju", state: "SE", lat: -10.91, lng: -37.07 },
  { city: "Nossa Senhora do Socorro", state: "SE", lat: -10.86, lng: -37.13 },
  { city: "Maceió", state: "AL", lat: -9.67, lng: -35.74 },
  { city: "Arapiraca", state: "AL", lat: -9.75, lng: -36.66 },
  { city: "Recife", state: "PE", lat: -8.05, lng: -34.88 },
  { city: "Jaboatão dos Guararapes", state: "PE", lat: -8.11, lng: -35.01 },
  { city: "Olinda", state: "PE", lat: -8.01, lng: -34.86 },
  { city: "Caruaru", state: "PE", lat: -8.28, lng: -35.98 },
  { city: "Petrolina", state: "PE", lat: -9.39, lng: -40.5 },
  { city: "João Pessoa", state: "PB", lat: -7.12, lng: -34.86 },
  { city: "Campina Grande", state: "PB", lat: -7.23, lng: -35.88 },
  { city: "Natal", state: "RN", lat: -5.79, lng: -35.21 },
  { city: "Parnamirim", state: "RN", lat: -5.92, lng: -35.26 },
  { city: "Mossoró", state: "RN", lat: -5.19, lng: -37.34 },
  { city: "Fortaleza", state: "CE", lat: -3.73, lng: -38.52 },
  { city: "Caucaia", state: "CE", lat: -3.74, lng: -38.66 },
  { city: "Maracanaú", state: "CE", lat: -3.88, lng: -38.63 },
  { city: "Juazeiro do Norte", state: "CE", lat: -7.21, lng: -39.32 },
  { city: "Sobral", state: "CE", lat: -3.69, lng: -40.35 },
  { city: "Teresina", state: "PI", lat: -5.09, lng: -42.8 },
  { city: "Parnaíba", state: "PI", lat: -2.9, lng: -41.78 },
  { city: "São Luís", state: "MA", lat: -2.53, lng: -44.3 },
  { city: "Imperatriz", state: "MA", lat: -5.52, lng: -47.47 },
  { city: "Belém", state: "PA", lat: -1.46, lng: -48.5 },
  { city: "Ananindeua", state: "PA", lat: -1.37, lng: -48.37 },
  { city: "Santarém", state: "PA", lat: -2.44, lng: -54.71 },
  { city: "Marabá", state: "PA", lat: -5.37, lng: -49.12 },
  { city: "Macapá", state: "AP", lat: 0.03, lng: -51.07 },
  { city: "Manaus", state: "AM", lat: -3.12, lng: -60.02 },
  { city: "Boa Vista", state: "RR", lat: 2.82, lng: -60.67 },
  { city: "Porto Velho", state: "RO", lat: -8.76, lng: -63.9 },
  { city: "Ji-Paraná", state: "RO", lat: -10.88, lng: -61.95 },
  { city: "Rio Branco", state: "AC", lat: -9.97, lng: -67.81 },
  { city: "Palmas", state: "TO", lat: -10.18, lng: -48.33 },
  { city: "Araguaína", state: "TO", lat: -7.19, lng: -48.21 },
]

const FALLBACK: ToastCity[] = [
  { city: "São Paulo", state: "SP" },
  { city: "Belo Horizonte", state: "MG" },
  { city: "Salvador", state: "BA" },
  { city: "Curitiba", state: "PR" },
  { city: "Fortaleza", state: "CE" },
  { city: "Goiânia", state: "GO" },
  { city: "Porto Alegre", state: "RS" },
  { city: "Recife", state: "PE" },
  { city: "Campinas", state: "SP" },
  { city: "Florianópolis", state: "SC" },
]

const NEARBY_COUNT = 8

function normalize(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim()
}

function distanceSq(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const dLat = a.lat - b.lat
  const dLng = (a.lng - b.lng) * Math.cos((a.lat * Math.PI) / 180)
  return dLat * dLat + dLng * dLng
}

/**
 * Builds the sales-toast city sequence: nearby cities first, with the lead's own
 * city interleaved twice (2nd and 5th toast), then the remaining nearby cities.
 */
export function buildToastCities(input: {
  city: string | null
  state?: string | null
  lat?: number | null
  lng?: number | null
}): ToastCity[] {
  const leadKey = input.city ? normalize(input.city) : null
  const known = leadKey ? BR_CITIES.find((c) => normalize(c.city) === leadKey) : undefined
  const origin =
    input.lat != null && input.lng != null && Number.isFinite(input.lat) && Number.isFinite(input.lng)
      ? { lat: input.lat, lng: input.lng }
      : known
        ? { lat: known.lat, lng: known.lng }
        : null

  let nearby: ToastCity[]
  if (origin) {
    nearby = BR_CITIES.filter((c) => normalize(c.city) !== leadKey)
      .sort((a, b) => distanceSq(origin, a) - distanceSq(origin, b))
      .slice(0, NEARBY_COUNT)
      .map(({ city, state }) => ({ city, state }))
  } else if (input.state) {
    const sameState = BR_CITIES.filter((c) => c.state === input.state && normalize(c.city) !== leadKey)
    nearby = sameState.length > 0 ? sameState.map(({ city, state }) => ({ city, state })) : FALLBACK
  } else {
    nearby = FALLBACK
  }

  if (!input.city) return nearby

  const lead: ToastCity = { city: input.city, state: known?.state ?? input.state ?? "" }
  const sequence = [...nearby]
  sequence.splice(1, 0, lead)
  sequence.splice(Math.min(4, sequence.length), 0, lead)
  return sequence
}
