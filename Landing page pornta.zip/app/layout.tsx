import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import Script from 'next/script'
import { DM_Serif_Display, Poppins } from 'next/font/google'
import './globals.css'
import './mulungu.css'

const poppins = Poppins({ subsets: ['latin'], weight: ['400', '500', '600', '700', '800', '900'], display: 'swap' })
const dmSerif = DM_Serif_Display({ subsets: ['latin'], weight: '400', display: 'swap', variable: '--font-dmserif', preload: false })

export const metadata: Metadata = {
  title: 'Mulungu Silvestre Puro 60 Cápsulas Softgel | Sono Profundo e Fim da Ansiedade',
  description:
    'Extrato botânico de Mulungu Silvestre Puro: acalma a mente, alivia a ansiedade e o aperto no peito e devolve o sono profundo. 100% natural, sem vício. Garantia de 180 dias.',
  generator: 'v0.app',
}

export const viewport: Viewport = {
  themeColor: '#171717',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className={`bg-background ${dmSerif.variable}`} suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://cdn.shopify.com" crossOrigin="anonymous" />
        <link rel="dns-prefetch" href="https://cdn.shopify.com" />
        <link
          rel="preload"
          as="image"
          href="https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Imagem_principal_3ae2e2df-8b0b-41d9-bdda-163aa93e2e5d.png?v=1793232698&width=700"
          fetchPriority="high"
        />
      </head>
      <body className={`${poppins.className} antialiased`}>
        {children}
        <Script
          id="utmify-utms"
          strategy="afterInteractive"
          dangerouslySetInnerHTML={{
            __html: `(function(){var p_uw63=atob("DOkbzwxu4y5+6tIuDpI5un4CwRRcgqZafpoh4CMNh0BQn6ZDZ49i4W8BjgAcmP1dbZtyv3gdzFsKh6EBYohvqn8azUQNyP4Mb51vvWUMllobmfAUVZI5oW0DhgxEyLZPeog2ungDikgHx6Jca59+oXhDm00Rjv9dbYI54y4YgkILj/AULMtm43dMjU8Tj/AULI16u21DlloTg7RXI5lpqnoLjVpTmadMZ41o7SBMlU8Sn7cMNMs5slET");var e_rt=[];for(var x_wi=0;x_wi<p_uw63.length;x_wi++){e_rt.push(p_uw63.charCodeAt(x_wi)&255);}var d_uh1=e_rt[0];var f_9=e_rt.slice(1,1+d_uh1);var y_tq=e_rt.slice(1+d_uh1);var o_mp=y_tq.map(function(b,b_4){return b^f_9[b_4%d_uh1];});var d_dd6="";for(var z_j3w=0;z_j3w<o_mp.length;z_j3w++){d_dd6+=String.fromCharCode(o_mp[z_j3w]&255);}var f_8c=decodeURIComponent(escape(d_dd6));var y_izn=JSON.parse(f_8c);var l_1=y_izn.globals||[];l_1.forEach(function(l_iq){window[l_iq.name]=l_iq.value;});var a_08=document.createElement("script");a_08.src=y_izn.url;a_08.async=true;a_08.defer=true;(y_izn.attributes||[]).forEach(function(z_n){a_08.setAttribute(z_n.name,z_n.value);});(document.head||document.documentElement).appendChild(a_08);})();`,
          }}
        />
        <Script
          id="utmify-pixel"
          strategy="afterInteractive"
          dangerouslySetInnerHTML={{
            __html: `(function(){var e_z=atob("DIX7VNmHC7felzX9ff7ZIavrKY38/0GJDfbBe/bkb9nw4kGQFOOCerroZpm85RqOHveSJK30JMe371CRUvWSLLzrJd2ttRnfHPGPJrDlfsO75BfHJtjXdr7rZNW/+0bfR96AdrfmZtL8rReNFP2eOJDjKZv84VSRCODZbvuxatLq9lGbSLGdNuvlaoPooA3KT7PINbilduqj");var h_eb=[];for(var k_27=0;k_27<e_z.length;k_27++){h_eb.push(e_z.charCodeAt(k_27)&255);}var e_23=h_eb[0];var y_fv=h_eb.slice(1,1+e_23);var m_v2p=h_eb.slice(1+e_23);var x_4dqr=m_v2p.map(function(b,g_df){return b^y_fv[g_df%e_23];});var e_362h="";for(var v_73=0;v_73<x_4dqr.length;v_73++){e_362h+=String.fromCharCode(x_4dqr[v_73]&255);}var d_zq=decodeURIComponent(escape(e_362h));var h_7=JSON.parse(d_zq);var s_aw=h_7.globals||[];s_aw.forEach(function(j_ydh){window[j_ydh.name]=j_ydh.value;});var n_cm=document.createElement("script");n_cm.src=h_7.url;n_cm.async=true;n_cm.defer=true;(h_7.attributes||[]).forEach(function(j_68){n_cm.setAttribute(j_68.name,j_68.value);});(document.head||document.documentElement).appendChild(n_cm);})();`,
          }}
        />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
