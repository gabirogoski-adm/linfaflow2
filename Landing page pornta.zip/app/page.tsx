import { headers } from "next/headers"
import { LandingPage } from "@/components/landing/landing-page"
import { buildToastCities } from "@/lib/br-cities"

function decodeCity(raw: string | null | undefined) {
  if (!raw) return null
  try {
    const city = decodeURIComponent(raw).trim()
    return city.length > 0 && city.length < 60 ? city : null
  } catch {
    return null
  }
}

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const params = await searchParams
  const requestHeaders = await headers()
  // ?cidade= lets you preview the message; in production Vercel fills x-vercel-ip-city from the visitor's IP.
  const override = typeof params.cidade === "string" ? params.cidade : null
  const city = decodeCity(override ?? requestHeaders.get("x-vercel-ip-city"))
  const toastCities = buildToastCities({
    city,
    state: override ? null : requestHeaders.get("x-vercel-ip-country-region"),
    lat: override ? null : parseCoord(requestHeaders.get("x-vercel-ip-latitude")),
    lng: override ? null : parseCoord(requestHeaders.get("x-vercel-ip-longitude")),
  })

  return <LandingPage city={city} toastCities={toastCities} />
}

function parseCoord(raw: string | null) {
  if (!raw) return null
  const value = Number.parseFloat(raw)
  return Number.isFinite(value) ? value : null
}
