const ROWS = [
  { label: "Vicia ou gera tolerância", bad: "Sim", good: "Não" },
  { label: "Efeito ressaca ao acordar", bad: "Sim, acorda dopada", good: "Zero, acorda disposta" },
  { label: "Precisa de receita controlada", bad: "Sim", good: "Não" },
  { label: "Age na raiz (sistema nervoso)", bad: "Só mascara", good: "Sim, modula o GABA" },
  { label: "Origem", bad: "Química sintética", good: "100% natural e vegano" },
  { label: "Alivia tensão muscular", bad: "Não", good: "Sim" },
]

export function Comparison() {
  return (
    <section className="sec-white">
      <div className="wrap">
        <span className="sec-eyebrow">A diferença na prática</span>
        <h2 className="center anim in">
          <span className="tarja">Tarja preta</span> vs. <span style={{ color: "#15803D" }}>Mulungu Silvestre Puro</span>
        </h2>
        <p className="subh anim in">Veja por que milhares de mulheres estão trocando de lado</p>
        <div className="cmp-table anim in" role="table" aria-label="Comparação entre remédio tarja preta e Mulungu">
          <div className="cmp-row cmp-head" role="row">
            <span role="columnheader"></span>
            <span role="columnheader" className="cmp-bad-h">Tarja preta</span>
            <span role="columnheader" className="cmp-good-h">Mulungu</span>
          </div>
          {ROWS.map((r) => (
            <div className="cmp-row" role="row" key={r.label}>
              <span role="cell" className="cmp-label">{r.label}</span>
              <span role="cell" className="cmp-bad">
                <i aria-hidden="true">✕</i> {r.bad}
              </span>
              <span role="cell" className="cmp-good">
                <i aria-hidden="true">✓</i> {r.good}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
