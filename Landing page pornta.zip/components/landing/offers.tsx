"use client"

import { Check, ChevronRight } from "lucide-react"
import { KITS, cdnImg } from "@/lib/mulungu-data"
import { PaymentBadges } from "./payment-badges"

const RECOMMENDED_KIT_ID = "kit-2"
const DISPLAY_ORDER = ["kit-2", "kit-3", "kit-1"].map((id) => KITS.find((k) => k.id === id)!)

const splitPrice = (price: string) => price.replace(/[^\d,]/g, "").split(",") as [string, string]

// Carries the visitor's UTMs to the checkout even if UTMify hasn't rewritten this link yet.
const forwardTrackingParams = (event: React.MouseEvent<HTMLAnchorElement>) => {
  const link = event.currentTarget
  const target = new URL(link.href)
  new URLSearchParams(window.location.search).forEach((value, key) => {
    if (!target.searchParams.has(key)) target.searchParams.set(key, value)
  })
  link.href = target.toString()
}

export function Offers({ variant }: { variant: "main" | "final" }) {
  const isMain = variant === "main"

  return (
    <section className="sec-white pricing-offers-section" id={isMain ? "offers" : "offer2"} style={{ paddingBottom: 16 }}>
      <div className="wrap">
        <div className="offers-wide">
          {isMain ? (
            <div id="escolha-protocolo" style={{ scrollMarginTop: 80, textAlign: "center", marginBottom: 20 }}>
              <h2 id="escolha-seu-kit" className="sec-title" style={{ margin: 0 }}>
                Escolha o seu <span className="green">kit</span>
              </h2>
            </div>
          ) : (
            <h2 className="center sec-title" style={{ marginBottom: 20 }}>
              Durma em paz <span className="green">a partir de hoje</span>
            </h2>
          )}

          <div className="kit-cards">
            {DISPLAY_ORDER.map((kit) => {
              const featured = kit.id === RECOMMENDED_KIT_ID
              const [reais, cents] = splitPrice(kit.newPrice)
              return (
                <a
                  key={`${variant}-${kit.id}`}
                  href={kit.url}
                  onClick={forwardTrackingParams}
                  className={`kit-card js-buy cta-${kit.id}${featured ? " is-featured" : ""}`}
                  aria-label={`Comprar ${kit.title} por ${kit.newPrice}`}
                >
                  <span className="kit-ribbon">{kit.tag}</span>
                  <span className="kit-headline">{kit.title}</span>

                  <span className="kit-media">
                    {kit.bottles === 2 ? (
                      <span className="kit-pair">
                        <img src={cdnImg(kit.image, 400)} alt="" loading="lazy" decoding="async" />
                        <img src={cdnImg(kit.image, 400)} alt="" loading="lazy" decoding="async" />
                      </span>
                    ) : (
                      <img src={cdnImg(kit.image, 500)} alt="" loading="lazy" decoding="async" />
                    )}
                  </span>

                  <span className="kit-old">De {kit.oldPrice}</span>
                  <span className="kit-price">
                    <span className="kit-cur">R$</span>
                    <span className="kit-int">{reais}</span>
                    <span className="kit-cents">,{cents}</span>
                  </span>

                  <span className="kit-perks">
                    {kit.perks.map((perk) => (
                      <span key={perk} className="kit-perk">
                        <Check aria-hidden="true" />
                        {perk}
                      </span>
                    ))}
                  </span>

                  <span className="kit-cta">
                    Quero este <ChevronRight aria-hidden="true" />
                  </span>
                </a>
              )
            })}
          </div>

          <div className="paystrip">
            <span className="ps-lock">🔒 Pagamento 100% seguro</span>
            <PaymentBadges />
          </div>
        </div>
      </div>
    </section>
  )
}
