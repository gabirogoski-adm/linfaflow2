"use client"

import { useEffect, useRef, useState } from "react"
import { ArrowLeft, Check, RotateCcw, X } from "lucide-react"
import { scrollToOffers } from "@/lib/scroll"

type Area = "sono" | "ansiedade"

type Question = {
  area: Area
  short: string
  question: string
  image: string
  yesValue: number
  noValue: number
  treats: string
}

const QUESTIONS: Question[] = [
  {
    area: "sono",
    short: "Demora",
    question: "Você deita e demora mais de 30 minutos para pegar no sono?",
    image: "/images/quiz-1.webp",
    yesValue: 92,
    noValue: 44,
    treats: "Ação indutora do sono: avisa o corpo que é hora de dormir.",
  },
  {
    area: "ansiedade",
    short: "Mente",
    question: "Sua mente fica acelerada, pensando em tudo ao mesmo tempo?",
    image: "/images/quiz-2.webp",
    yesValue: 88,
    noValue: 40,
    treats: "Acalma o sistema nervoso e desacelera os pensamentos.",
  },
  {
    area: "sono",
    short: "Madrugada",
    question: "Você acorda de madrugada e não consegue voltar a dormir?",
    image: "/images/quiz-3.webp",
    yesValue: 95,
    noValue: 46,
    treats: "Ajuda a manter o sono profundo até o amanhecer.",
  },
  {
    area: "ansiedade",
    short: "Peito",
    question: "Sente aperto no peito ou o coração acelerado sem motivo?",
    image: "/images/quiz-4.webp",
    yesValue: 84,
    noValue: 38,
    treats: "Reduz a sensação de aperto e o coração disparado.",
  },
  {
    area: "ansiedade",
    short: "Tensão",
    question: "Seus ombros, pescoço ou mandíbula vivem tensos?",
    image: "/images/quiz-5.webp",
    yesValue: 90,
    noValue: 42,
    treats: "Diminui a tensão muscular acumulada no corpo.",
  },
  {
    area: "sono",
    short: "Cansaço",
    question: "Você acorda cansada, como se nem tivesse dormido?",
    image: "/images/quiz-6.webp",
    yesValue: 93,
    noValue: 45,
    treats: "Regula o ciclo do sono para você acordar descansada.",
  },
  {
    area: "ansiedade",
    short: "Emoção",
    question: "Fica irritada ou chora por coisas pequenas?",
    image: "/images/quiz-7.webp",
    yesValue: 86,
    noValue: 41,
    treats: "Traz equilíbrio emocional e mais paciência no dia a dia.",
  },
]

const MULUNGU_VALUES = [22, 18, 20, 15, 17, 14, 12]
const TOTAL = QUESTIONS.length

function areaLevel(answers: boolean[], area: Area) {
  const items = QUESTIONS.map((q, i) => ({ q, a: answers[i] })).filter((x) => x.q.area === area)
  const yes = items.filter((x) => x.a).length
  return Math.round(38 + (yes / items.length) * 58)
}

function capitalize(text: string) {
  return text.charAt(0).toUpperCase() + text.slice(1)
}

function levelLabel(pct: number) {
  if (pct >= 80) return "Alto"
  if (pct >= 60) return "Moderado"
  return "Em alerta"
}

export function AnxietyQuiz() {
  const [answers, setAnswers] = useState<boolean[]>([])
  const [picked, setPicked] = useState<boolean | null>(null)
  const quizRef = useRef<HTMLDivElement>(null)

  const step = answers.length
  const done = step >= TOTAL
  const current = QUESTIONS[Math.min(step, TOTAL - 1)]

  useEffect(() => {
    const el = quizRef.current
    if (!el) return
    const observer = new IntersectionObserver(([entry]) => {
      document.body.classList.toggle("quiz-in-view", entry.isIntersecting)
    })
    observer.observe(el)
    return () => {
      observer.disconnect()
      document.body.classList.remove("quiz-in-view")
    }
  }, [])

  useEffect(() => {
    QUESTIONS.forEach((q) => {
      const img = new Image()
      img.src = q.image
    })
  }, [])

  const answer = (value: boolean) => {
    if (picked !== null) return
    setPicked(value)
    window.setTimeout(() => {
      setAnswers((prev) => [...prev, value])
      setPicked(null)
    }, 380)
  }

  const goBack = () => setAnswers((prev) => prev.slice(0, -1))

  const restart = () => {
    setAnswers([])
    quizRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  const progressPct = Math.round((step / TOTAL) * 100)

  return (
    <section className="sec-white qz-section" id="quiz">
      <div className="wrap">
        <span className="sec-eyebrow">Teste gratuito · 7 perguntas</span>
        <h2 className="center sec-title qz-heading">
          Descubra seu nível de
          <br />
          <span className="green">ansiedade e falta de sono</span>
        </h2>
        <p className="lead-text">
          A paciente 1401 também achava que era &quot;normal&quot; deitar e não desligar. Responda com sinceridade:
          leva menos de 30 segundos.
        </p>

        <div ref={quizRef} className="qz-card">
          {!done ? (
            <div className="qz-step" key={step}>
              <div className="qz-top">
                <span className={`qz-area qz-area-${current.area}`}>
                  {current.area === "sono" ? "Sono" : "Ansiedade"}
                </span>
                <span className="qz-counter" aria-live="polite">
                  <b>{step}</b> de {TOTAL} respondidas
                </span>
              </div>

              <div className="qz-media">
                <img src={current.image || "/placeholder.svg"} alt="" width={640} height={640} />
                <span className="qz-qnum">Pergunta {step + 1}</span>
              </div>

              <h3 className="qz-question">{current.question}</h3>

              <div className="qz-options" role="group" aria-label="Resposta">
                <button
                  type="button"
                  className={`qz-opt qz-yes ${picked === true ? "picked" : ""}`}
                  onClick={() => answer(true)}
                  disabled={picked !== null}
                >
                  <Check aria-hidden="true" size={22} strokeWidth={3} />
                  Sim
                </button>
                <button
                  type="button"
                  className={`qz-opt qz-no ${picked === false ? "picked" : ""}`}
                  onClick={() => answer(false)}
                  disabled={picked !== null}
                >
                  <X aria-hidden="true" size={22} strokeWidth={3} />
                  Não
                </button>
              </div>

              <div className="qz-progress">
                <div
                  className="qz-bar"
                  role="progressbar"
                  aria-valuemin={0}
                  aria-valuemax={TOTAL}
                  aria-valuenow={step}
                  aria-label="Progresso do teste"
                >
                  <i style={{ width: `${progressPct}%` }} />
                </div>
                <div className="qz-dots" aria-hidden="true">
                  {QUESTIONS.map((q, i) => (
                    <span
                      key={q.short}
                      className={i < step ? (answers[i] ? "yes" : "no") : i === step ? "now" : ""}
                    />
                  ))}
                </div>
                {step > 0 && (
                  <button type="button" className="qz-back" onClick={goBack}>
                    <ArrowLeft aria-hidden="true" size={15} />
                    Voltar
                  </button>
                )}
              </div>
            </div>
          ) : (
            <QuizResult answers={answers} onRestart={restart} />
          )}
        </div>
      </div>
    </section>
  )
}

function QuizResult({ answers, onRestart }: { answers: boolean[]; onRestart: () => void }) {
  const anxiety = areaLevel(answers, "ansiedade")
  const sleep = areaLevel(answers, "sono")
  const yesItems = QUESTIONS.filter((_, i) => answers[i])
  const treated = yesItems.length > 0 ? yesItems : QUESTIONS.filter((_, i) => i < 3)

  return (
    <div className="qz-result" aria-live="polite">
      <span className="qz-result-tag">Seu resultado</span>
      <h3 className="qz-result-title">
        {yesItems.length >= 4
          ? "Seu corpo está pedindo socorro"
          : yesItems.length >= 2
            ? "Sua mente não está conseguindo desligar"
            : "Seu sistema nervoso já dá sinais de alerta"}
      </h3>
      <p className="qz-result-sub">
        Você respondeu <b>sim</b> para <b>{yesItems.length} de {TOTAL}</b> sinais. Veja como eles estão hoje e como
        ficam com o Mulungu Silvestre Puro.
      </p>

      <div className="qz-gauges">
        <Gauge label="Ansiedade" value={anxiety} />
        <Gauge label="Falta de sono" value={sleep} />
      </div>

      <LineChart answers={answers} />

      <h4 className="qz-treat-title">O Mulungu age exatamente no que você respondeu:</h4>
      <ul className="qz-treat-list">
        {treated.map((q) => (
          <li key={q.short}>
            <span className="qz-treat-ico" aria-hidden="true">
              <Check size={14} strokeWidth={3.5} />
            </span>
            <span>
              <b>{capitalize(q.question.replace("Você ", "").replace("?", ""))}</b>
              <br />
              {q.treats}
            </span>
          </li>
        ))}
      </ul>

      <a href="#offers" className="btn qz-cta" onClick={scrollToOffers}>
        Ver kit recomendado para mim
      </a>
      <button type="button" className="qz-restart" onClick={onRestart}>
        <RotateCcw aria-hidden="true" size={14} />
        Refazer o teste
      </button>
    </div>
  )
}

function Gauge({ label, value }: { label: string; value: number }) {
  return (
    <div className="qz-gauge">
      <div className="qz-gauge-head">
        <span>{label}</span>
        <b>{levelLabel(value)}</b>
      </div>
      <div className="qz-gauge-bar">
        <i style={{ width: `${value}%` }} />
      </div>
      <span className="qz-gauge-pct">{value}%</span>
    </div>
  )
}

function LineChart({ answers }: { answers: boolean[] }) {
  const W = 340
  const H = 200
  const padL = 30
  const padR = 22
  const padT = 16
  const padB = 34
  const innerW = W - padL - padR
  const innerH = H - padT - padB

  const x = (i: number) => padL + (innerW / (TOTAL - 1)) * i
  const y = (v: number) => padT + innerH - (v / 100) * innerH

  const userValues = QUESTIONS.map((q, i) => (answers[i] ? q.yesValue : q.noValue))
  const toPath = (vals: number[]) => vals.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ")
  const userPath = toPath(userValues)
  const areaPath = `${userPath} L${x(TOTAL - 1)},${y(0)} L${x(0)},${y(0)} Z`

  return (
    <figure className="qz-chart">
      <figcaption className="qz-legend">
        <span className="lg-you">Você hoje</span>
        <span className="lg-mul">Com Mulungu</span>
      </figcaption>
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Gráfico comparando a intensidade dos seus sinais hoje com o resultado esperado com o Mulungu">
        <defs>
          <linearGradient id="qzArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#A8261D" stopOpacity="0.22" />
            <stop offset="100%" stopColor="#A8261D" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0, 25, 50, 75, 100].map((v) => (
          <g key={v}>
            <line x1={padL} x2={W - padR} y1={y(v)} y2={y(v)} className="qz-grid" />
            <text x={padL - 6} y={y(v) + 3} className="qz-axis" textAnchor="end">
              {v}
            </text>
          </g>
        ))}
        <path d={areaPath} fill="url(#qzArea)" className="qz-area-fill" />
        <path d={userPath} className="qz-line-you" pathLength={1} />
        <path d={toPath(MULUNGU_VALUES)} className="qz-line-mul" pathLength={1} />
        {userValues.map((v, i) => (
          <circle
            key={QUESTIONS[i].short}
            cx={x(i)}
            cy={y(v)}
            r={answers[i] ? 5 : 4}
            className={answers[i] ? "qz-pt-yes" : "qz-pt-no"}
            style={{ animationDelay: `${0.3 + i * 0.12}s` }}
          />
        ))}
        {MULUNGU_VALUES.map((v, i) => (
          <circle key={`m-${QUESTIONS[i].short}`} cx={x(i)} cy={y(v)} r={3.5} className="qz-pt-mul" />
        ))}
        {QUESTIONS.map((q, i) => (
          <text key={`l-${q.short}`} x={x(i)} y={H - 12} className="qz-xlabel" textAnchor="middle">
            {q.short}
          </text>
        ))}
      </svg>
      <p className="qz-chart-note">
        Os pontos em vermelho forte são os sinais que você marcou como <b>sim</b>.
      </p>
    </figure>
  )
}
