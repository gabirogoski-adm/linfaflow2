"use client"

import { useRef, useState } from "react"
import useSWR from "swr"
import { MapPin, Play } from "lucide-react"

const DOCTOR_VIDEO_URL = "/videos/dr-mauricio-recado.mp4"
const DOCTOR_POSTER = "/images/dr-mauricio-foto-poster.webp"

type GeoResponse = { city?: string }

const fetchGeoCity = async (url: string) => {
  const res = await fetch(url)
  if (!res.ok) return null
  const data = (await res.json()) as GeoResponse
  const city = data.city?.trim()
  return city && city.length < 60 ? city : null
}

export function DoctorMessage({ city: serverCity }: { city: string | null }) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [playing, setPlaying] = useState(false)

  // Fallback when the server could not resolve the city (e.g. the preview environment).
  const { data: geoCity } = useSWR(serverCity ? null : "https://get.geojs.io/v1/ip/geo.json", fetchGeoCity, {
    revalidateOnFocus: false,
    shouldRetryOnError: false,
  })
  const city = serverCity ?? geoCity ?? null

  const play = () => {
    const video = videoRef.current
    if (!video) return
    video.muted = false
    setPlaying(true)
    video.play().catch(() => setPlaying(false))
  }

  return (
    <div className="doctor-msg">
      <h2 className="doctor-msg-title">
        {city ? (
          <>
            Se você é de
            <span className="city-line">
              <span className="city-chip">
                <MapPin aria-hidden="true" />
                {city}
              </span>
              ,
            </span>
            o Dr. Maurício tem um recadinho abaixo para você!
          </>
        ) : (
          <>O Dr. Maurício tem um recadinho abaixo para você!</>
        )}
      </h2>

      <div className="doctor-video">
        <video
          ref={videoRef}
          src={DOCTOR_VIDEO_URL}
          poster={DOCTOR_POSTER}
          playsInline
          preload="auto"
          controls={playing}
          onPause={() => setPlaying(false)}
          onPlay={() => setPlaying(true)}
        >
          <track kind="captions" />
        </video>
        {!playing && (
          <button type="button" className="doctor-video-play" onClick={play} aria-label="Assistir recado do Dr. Maurício">
            <span className="doctor-video-play-btn">
              <Play aria-hidden="true" />
            </span>
            <span className="doctor-video-play-label">Toque para assistir</span>
          </button>
        )}
      </div>
    </div>
  )
}
