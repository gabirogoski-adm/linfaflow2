"use client"

import { useState } from "react"
import { BedDouble, Clock, Moon, Waves } from "lucide-react"
import { GALLERY_SLIDES, cdnImg } from "@/lib/mulungu-data"

const INDICATIONS = [
  { icon: Moon, title: "Indutor do sono:", text: "avisa o corpo que é hora de dormir." },
  { icon: Waves, title: "Diminui a ansiedade", text: "e a tensão muscular." },
  { icon: BedDouble, title: "Induz o relaxamento", text: "na hora de deitar." },
  { icon: Clock, title: "Ajuda a controlar", text: "e regular o seu sono." },
]

export function Hero() {
  const [active, setActive] = useState(0)

  return (
    <section className="hero">
      <div className="wrap">
        <div className="hero-inner">
          <div className="gallery">
            <div className="hero-stage">
              {GALLERY_SLIDES.map((slide, i) => (
                <img
                  key={slide.src}
                  src={cdnImg(slide.src, 700)}
                  alt={slide.alt}
                  width={700}
                  height={700}
                  fetchPriority={i === 0 ? "high" : "low"}
                  loading={i === 0 ? "eager" : "lazy"}
                  decoding={i === 0 ? "sync" : "async"}
                  className={`hero-slide ${active === i ? "is-active" : ""}`}
                  aria-hidden={active !== i}
                />
              ))}
            </div>
            <div className="hero-thumbs">
              {GALLERY_SLIDES.map((slide, i) => (
                <button
                  key={slide.src}
                  type="button"
                  onClick={() => setActive(i)}
                  aria-label={`Ver imagem ${i + 1}`}
                  aria-current={active === i}
                  className={`hero-thumb ${active === i ? "is-active" : ""}`}
                >
                  <img src={cdnImg(slide.src, 140)} alt="" width={70} height={70} loading="lazy" decoding="async" />
                </button>
              ))}
            </div>
          </div>

          <h1 className="hero-title">
            <span className="hero-product">Mulungu Silvestre Puro</span>
            <span className="hero-kicker">
              Desligue a ansiedade sem remédio <span className="tarja">tarja preta</span>
            </span>
          </h1>

          <ul className="indications" aria-label="Indicações">
            {INDICATIONS.map(({ icon: Icon, title, text }) => (
              <li key={title} className="indication">
                <span className="indication-icon" aria-hidden="true">
                  <Icon />
                </span>
                <span>
                  <b>{title}</b> {text}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
