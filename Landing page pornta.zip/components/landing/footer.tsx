import { PaymentBadges } from "./payment-badges"

export function Footer() {
  return (
    <footer>
      <div className="wrap">
        <div className="logo" style={{ fontWeight: 800 }}>
          Extratos <span style={{ color: "#E87E38", fontWeight: 800 }}>Botânicos</span>
        </div>
        <p style={{ maxWidth: 460 }}>
          Mulungu Silvestre Puro: extrato botânico em cápsulas softgel, de colheita nativa e silvestre. Fórmula 100% natural
          para acalmar a mente, aliviar a ansiedade e devolver o sono profundo.
          <br />
          <br />
          Telefone / WhatsApp:{" "}
          <a href="tel:+5549991853360" style={{ color: "inherit" }}>
            +55 (49) 99185-3360
          </a>
          <br />
          E-mail:{" "}
          <a href="mailto:contato@vitaissuplementos.com" style={{ color: "inherit" }}>
            contato@vitaissuplementos.com
          </a>
          <br />
          Seg a Sex, 8h às 18h
        </p>
        <div className="footpays">
          <span className="lbl">Formas de pagamento aceitas</span>
          <PaymentBadges dark withHiper />
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "9px 18px", marginTop: 20, paddingTop: 16, borderTop: "1px solid #1c4d3c" }}>
          <a href="#" style={{ color: "#cfeadd", fontSize: 12, textDecoration: "none" }}>Termos de Uso</a>
          <a href="#" style={{ color: "#cfeadd", fontSize: 12, textDecoration: "none" }}>Política de Privacidade</a>
          <a href="#" style={{ color: "#cfeadd", fontSize: 12, textDecoration: "none" }}>Trocas e Devoluções</a>
        </div>
        <p style={{ fontSize: 11, opacity: 0.7, marginTop: 16, maxWidth: 640 }}>
          Este produto não é um medicamento e não substitui orientação médica. Os resultados podem variar de pessoa para
          pessoa. Gestantes, lactantes e pessoas em uso de medicamentos controlados devem consultar um médico antes do uso.
          <br />© {new Date().getFullYear()} Extratos Botânicos. Todos os direitos reservados.
        </p>
      </div>
    </footer>
  )
}
