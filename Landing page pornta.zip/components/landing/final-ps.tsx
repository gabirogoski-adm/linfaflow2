export function FinalPs() {
  return (
    <section className="sec-white">
      <div className="wrap">
        <div className="narrow-col final-ps">
          <p>
            <b>P.S.:</b> Se você chegou até aqui, provavelmente já tentou de tudo e ainda deita com a cabeça a mil. Você tem
            180 dias para testar o Mulungu Silvestre Puro. Se não voltar a dormir em paz, devolvemos o seu dinheiro.{" "}
            <b>O risco é todo nosso.</b> A única coisa que você perde esperando é mais uma noite em claro.
          </p>
        </div>
      </div>
    </section>
  )
}
