"use client"

import { useState } from "react"
import { PROOF_IMAGES, cdnImg } from "@/lib/mulungu-data"
import { TestimonialVideo } from "./testimonial-video"

const VIDEO_TESTIMONIAL = "https://cdn.shopify.com/videos/c/o/v/96a3475543db4c739e7a6f8a5770d946.mp4"

export function ProofCarousel() {
  const [paused, setPaused] = useState(false)
  const hold = () => setPaused(true)
  const release = () => setPaused(false)

  return (
    <section className="sec-white" aria-label="Fotos de clientes que já receberam o produto">
      <div className="wrap">
        <span className="sec-eyebrow">Clientes reais</span>
        <h2 className="center sec-title">
          Quem já recebeu <span className="green">aprova</span>
        </h2>
        <p className="lead-text">Mulheres de todo o Brasil que voltaram a dormir a noite inteira.</p>
        <div className="narrow-col proof-video">
          <TestimonialVideo src={VIDEO_TESTIMONIAL} />
        </div>
      </div>
      <div
        className={`proof-marquee ${paused ? "is-paused" : ""}`}
        onPointerDown={hold}
        onPointerUp={release}
        onPointerLeave={release}
        onPointerCancel={release}
        onContextMenu={(e) => e.preventDefault()}
      >
        <div className="proof-track">
          {[...PROOF_IMAGES, ...PROOF_IMAGES].map((src, i) => (
            <img
              key={`${src}-${i}`}
              src={cdnImg(src, 360)}
              alt={i < PROOF_IMAGES.length ? `Comentário de cliente ${i + 1}` : ""}
              aria-hidden={i >= PROOF_IMAGES.length}
              loading="lazy"
              decoding="async"
              draggable={false}
              className="proof-img"
            />
          ))}
        </div>
      </div>
    </section>
  )
}
