import { PROOF_IMAGES, REVIEWS, cdnImg } from "@/lib/mulungu-data"

const REVIEW_PHOTO_KEYS = ["carrossel_12.", "carrossel_10.", "carrossel_1.", "carrossel_11.", "carrossel_2.", "carrossel_3."]
const FEMALE_PHOTOS = REVIEW_PHOTO_KEYS.map((key) => PROOF_IMAGES.find((src) => src.includes(key)) ?? "")

const BARS = [
  { lab: "5 ★", w: "91%", cnt: "11.962" },
  { lab: "4 ★", w: "7%", cnt: "921" },
  { lab: "3 ★", w: "1%", cnt: "164" },
  { lab: "2 ★", w: "1%", cnt: "58" },
  { lab: "1 ★", w: "1%", cnt: "41" },
]

export function Reviews() {
  return (
    <section className="sec-white" id="reviews">
      <div className="wrap">
        <div className="guarantee-premium-card anim in">
          <div className="gpc-icon-wrap">
            <div className="gpc-shield-badge">🛡️</div>
          </div>
          <div className="gpc-content">
            <span className="gpc-tag">RISCO ZERO PARA VOCÊ</span>
            <h3 className="gpc-title">GARANTIA DE 180 DIAS</h3>
            <p className="gpc-subtitle">100% de satisfação ou seu dinheiro de volta, sem perguntas</p>
          </div>
        </div>

        <h2 className="center anim in" style={{ marginTop: 42 }}>
          Avaliações do produto
        </h2>
        <p className="subh anim in">Confira as opiniões de quem já voltou a dormir em paz!</p>

        <div className="rev-head anim in">
          <div className="score">
            4,9<span className="stars">★★★★★</span>
            <small>13.146 avaliações</small>
          </div>
          <div className="bars">
            {BARS.map((b) => (
              <div className="barrow" key={b.lab}>
                <span className="lab">{b.lab}</span>
                <span className="track">
                  <i style={{ width: b.w }}></i>
                </span>
                <span className="cnt">{b.cnt}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="revs anim in">
          {REVIEWS.map((rev, i) => (
            <div key={rev.name} className="rev">
              <div className="top">
                <img className="av av-photo" src={cdnImg(FEMALE_PHOTOS[i % FEMALE_PHOTOS.length], 96)} alt="" width={44} height={44} loading="lazy" decoding="async" />
                <div>
                  <div className="name">{rev.name}</div>
                  <div className="verif">✓ Verificada</div>
                </div>
              </div>
              <div className="stars">★★★★★</div>
              <p>“{rev.text}”</p>
              <div className="date">{rev.date}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
