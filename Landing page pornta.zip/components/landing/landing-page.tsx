"use client"

import { useCallback, useState } from "react"
import { Header } from "./header"
import { Hero } from "./hero"
import { BlessingStory } from "./blessing-story"
import { AnxietyQuiz } from "./anxiety-quiz"
import { AnxietyRoot } from "./anxiety-root"
import { Compounds } from "./compounds"
import { Comparison } from "./comparison"
import { Timeline } from "./timeline"
import { ProofCarousel } from "./proof-carousel"
import { Offers } from "./offers"
import { Reviews } from "./reviews"
import { Faq } from "./faq"
import { Footer } from "./footer"
import { SalesToast, StockBadge } from "./floating"
import type { ToastCity } from "@/lib/br-cities"
import { StickyOfferCta } from "./sticky-offer-cta"
import { MidCta } from "./mid-cta"
import { Benefits } from "./benefits"
import { FinalPs } from "./final-ps"

export function LandingPage({ city, toastCities }: { city: string | null; toastCities: ToastCity[] }) {
  const [stock, setStock] = useState(147)
  const [lastDeduction, setLastDeduction] = useState<number | null>(null)

  const handleSale = useCallback((bottles: number) => {
    setLastDeduction(bottles)
    setStock((s) => Math.max(12, s - bottles))
  }, [])

  return (
    <div className="min-h-screen">
      <Header />
      <StockBadge stock={stock} lastDeduction={lastDeduction} />
      <main>
        <Hero />
        <BlessingStory city={city} />
        <AnxietyQuiz />
        <AnxietyRoot />
        <Compounds />
        <Comparison />
        <Timeline />
        <MidCta
          title="Quanto mais noites seguidas, mais o sono se firma"
          text="Quem não interrompe o uso no meio do caminho é quem sente a ansiedade ir embora de vez."
          button="Quero começar hoje"
        />
        <ProofCarousel />
        <Benefits />
        <Offers variant="main" />
        <Reviews />
        <Faq />
        <Offers variant="final" />
        <FinalPs />
      </main>
      <Footer />
      <SalesToast stock={stock} onSale={handleSale} cities={toastCities} />
      <StickyOfferCta />
    </div>
  )
}
