"use client"

import { useEffect, useState, type MouseEvent } from "react"
import { scrollToOffers } from "@/lib/scroll"

function scrollToFinalOffers(e: MouseEvent) {
  scrollToOffers(e)
}

export function StickyOfferCta() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    let frame = 0
    const inView = (el: HTMLElement | null) => {
      if (!el) return false
      const r = el.getBoundingClientRect()
      return r.top < window.innerHeight && r.bottom > 0
    }

    const update = () => {
      frame = 0
      const trigger = document.getElementById("dormir-em-paz")
      if (!trigger) return
      const reachedTrigger = trigger.getBoundingClientRect().top < window.innerHeight
      const offersInView = inView(document.getElementById("offers")) || inView(document.getElementById("offer2"))
      setVisible(reachedTrigger && !offersInView)
    }

    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update)
    }

    update()
    window.addEventListener("scroll", onScroll, { passive: true })
    window.addEventListener("resize", onScroll)
    return () => {
      window.removeEventListener("scroll", onScroll)
      window.removeEventListener("resize", onScroll)
      if (frame) cancelAnimationFrame(frame)
    }
  }, [])

  return (
    <div className={`sticky-offer-cta${visible ? " is-visible" : ""}`} aria-hidden={!visible}>
      <a href="#offer2" onClick={scrollToFinalOffers} className="reveal-cta-btn" tabIndex={visible ? 0 : -1}>
        Ver kit recomendado
      </a>
    </div>
  )
}
