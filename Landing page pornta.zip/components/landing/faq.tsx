import { FAQS } from "@/lib/mulungu-data"

export function Faq() {
  return (
    <section className="sec-white">
      <div className="wrap">
        <span className="sec-eyebrow">Tire suas dúvidas</span>
        <h2 className="center anim in">Perguntas que você precisa ver respondidas</h2>
        <p className="lead-text" style={{ marginTop: 10 }}>
          As dúvidas mais comuns de quem está pensando em começar.
        </p>
        <div className="faq anim in" style={{ marginTop: 20 }}>
          {FAQS.map((item) => (
            <details key={item.question} className="faqitem faq-acc">
              <summary className="q">
                <span>{item.question}</span>
                <span className="faq-plus" aria-hidden="true" />
              </summary>
              <p className="a">{item.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}
