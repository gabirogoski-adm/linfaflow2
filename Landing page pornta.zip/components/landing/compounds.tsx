import { COMPOUNDS } from "@/lib/mulungu-data"

export function Compounds() {
  return (
    <section className="sec-white">
      <div className="wrap">
        <div className="narrow-col">
          <span className="sec-eyebrow">Fórmula aberta</span>
          <h2 className="center sec-title">
            Conheça o que tem por dentro de cada cápsula <span className="green">além do MULUNGU!</span>
          </h2>
          <ul className="cmpd-list">
            {COMPOUNDS.map((c) => (
              <li className="cmpd" key={c.name}>
                <img
                  src={c.img}
                  alt={c.name}
                  width={58}
                  height={58}
                  className="cmpd-img"
                  loading="lazy"
                  decoding="async"
                />
                <div>
                  <h3 className="cmpd-name">{c.name}</h3>
                  <p className="cmpd-text">{c.text}</p>
                </div>
              </li>
            ))}
          </ul>

        </div>
      </div>
    </section>
  )
}
