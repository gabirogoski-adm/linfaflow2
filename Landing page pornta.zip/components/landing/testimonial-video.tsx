"use client"

import { useEffect, useRef, useState } from "react"
import { Play, Volume2, VolumeX } from "lucide-react"

export function TestimonialVideo({ src }: { src: string }) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [ended, setEnded] = useState(false)
  const [muted, setMuted] = useState(false)
  const startedRef = useRef(false)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          if (video.ended) return
          video.muted = false
          video
            .play()
            .then(() => setMuted(false))
            .catch(() => {
              // Browsers block autoplay with sound until the user interacts; fall back to muted playback.
              video.muted = true
              setMuted(true)
              video.play().catch(() => {})
            })
          startedRef.current = true
        } else if (startedRef.current) {
          video.pause()
        }
      },
      { threshold: 0.5 },
    )
    observer.observe(video)

    const unlockSound = () => {
      if (!video.paused && video.muted) {
        video.muted = false
        setMuted(false)
      }
    }
    window.addEventListener("pointerdown", unlockSound)
    window.addEventListener("keydown", unlockSound)

    return () => {
      observer.disconnect()
      window.removeEventListener("pointerdown", unlockSound)
      window.removeEventListener("keydown", unlockSound)
    }
  }, [])

  const restart = () => {
    const video = videoRef.current
    if (!video) return
    video.currentTime = 0
    video.muted = false
    setMuted(false)
    setEnded(false)
    video.play().catch(() => {})
  }

  const toggleMute = () => {
    const video = videoRef.current
    if (!video) return
    video.muted = !video.muted
    setMuted(video.muted)
  }

  return (
    <div className="sq-video">
      <video ref={videoRef} src={src} playsInline preload="none" onEnded={() => setEnded(true)}>
        <track kind="captions" />
      </video>

      {ended ? (
        <button type="button" className="sq-video-play" onClick={restart} aria-label="Assistir novamente">
          <Play aria-hidden="true" />
        </button>
      ) : (
        <button type="button" className="sq-video-mute" onClick={toggleMute} aria-label={muted ? "Ativar som" : "Desativar som"}>
          {muted ? <VolumeX aria-hidden="true" /> : <Volume2 aria-hidden="true" />}
        </button>
      )}
    </div>
  )
}
