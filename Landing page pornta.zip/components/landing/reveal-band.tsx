export function RevealBand() {
  return (
    <section className="sec-white" style={{ paddingTop: 8 }}>
      <div className="wrap">
        <div className="narrow-col">
          <img
            className="benefits-img"
            src="https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Beneficios.png?v=1793232698&width=700"
            alt="Benefícios do Mulungu: controle da ansiedade, mente silenciada, sono reparador, alívio físico e sistema nervoso equilibrado"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  )
}
