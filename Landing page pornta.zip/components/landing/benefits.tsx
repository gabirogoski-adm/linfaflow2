const BENEFITS = [
  { strong: "Adormece mais rápido", text: "a mente desacelera e você pega no sono sem ficar rolando na cama." },
  { strong: "Dorme a noite inteira", text: "menos despertares de madrugada e um sono mais profundo." },
  { strong: "Acorda disposta", text: "sem a ressaca e a moleza dos remédios para dormir." },
  { strong: "Pensamentos param de girar", text: "a preocupação perde força e você consegue desligar." },
  { strong: "Peito e respiração soltam", text: "o aperto e a sensação de falta de ar aliviam." },
  { strong: "Ombros e mandíbula relaxam", text: "a tensão muscular do dia vai embora." },
  { strong: "Mais paciência no dia a dia", text: "menos irritação e mais leveza com a família." },
  { strong: "Sem viciar e sem dopar", text: "você usa o tempo que precisar e para quando quiser." },
]

export function Benefits() {
  return (
    <section className="sec-white">
      <div className="wrap">
        <div className="narrow-col">
          <span className="sec-eyebrow">Resumo dos benefícios</span>
          <h2 className="center sec-title">
            O que o Mulungu faz pelo seu <span className="green">sono, sua mente e seu corpo</span>
          </h2>
          <p className="lead-text">Tudo o que você vai sentir mudar, em um só lugar.</p>
          <ul className="benefit-list">
            {BENEFITS.map((b) => (
              <li key={b.strong}>
                <span className="benefit-check" aria-hidden="true" />
                <span>
                  <b>{b.strong}:</b> {b.text}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
