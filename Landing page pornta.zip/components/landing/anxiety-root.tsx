"use client"

import { useEffect, useRef } from "react"

const LOOP_VIDEO = "https://cdn.shopify.com/videos/c/o/v/6da3f7cebdc04531bec89995455deae7.mp4"

export function AnxietyRoot() {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) video.play().catch(() => {})
        else video.pause()
      },
      { threshold: 0.1, rootMargin: "200px 0px" },
    )
    observer.observe(video)
    return () => observer.disconnect()
  }, [])

  return (
    <section className="sec-white">
      <div className="wrap">
        <div className="narrow-col">
          <span className="sec-eyebrow">A causa por trás dos sinais</span>
          <h2 className="center sec-title">
            Você sabe de onde <span className="green">vem a ansiedade?</span>
          </h2>
          <p className="lead-text" style={{ marginBottom: 10 }}>
            Se você marcou dois sinais ou mais, não é frescura e nem fraqueza. Existe um motivo físico, e ele tem solução.
          </p>

          <p className="lead-text">
            Ela começa quando o seu <b>sistema nervoso fica preso no modo de alerta</b>. Anos de preocupação e as mudanças
            hormonais depois dos 45 enfraquecem o <b>GABA</b>, o freio natural do cérebro. E o corpo não sabe mais desligar.
          </p>

          <div className="why-box">
            <h3 className="why-title">Por que o Mulungu funciona?</h3>
            <p>
              Os alcaloides do Mulungu ativam os mesmos receptores da calma que o GABA usa. O cortisol baixa, os pensamentos
              param de girar e o sono profundo volta. <b>Sem dopar, sem viciar, sem ressaca.</b>
            </p>
            <p>
              É por isso que tantas mulheres que já tinham desistido estão dormindo a noite inteira de novo.
            </p>
          </div>

          <div className="sq-video" style={{ marginTop: 20 }}>
            <video ref={videoRef} src={LOOP_VIDEO} muted loop playsInline preload="none" aria-label="Mulungu Silvestre Puro em ação" />
          </div>

        </div>
      </div>
    </section>
  )
}
