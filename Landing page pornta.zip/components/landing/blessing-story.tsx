import { DoctorMessage } from "./doctor-message"

const FB_COMMENT =
  "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Comentario_1_logo_abaixo_2_video_apos_a_tabela_de_comparacao.png?v=1793232696&width=700"

export function BlessingStory({ city }: { city: string | null }) {
  return (
    <section className="sec-white">
      <div className="wrap">
        <div className="narrow-col">
          <aside className="verified-note" aria-label="Informação verificada">
            <img
              src="/images/dr-mauricio-foto-avatar.webp"
              alt="Dr. Maurício, psicólogo"
              className="verified-note-img"
              width={64}
              height={64}
              loading="lazy"
            />
            <div className="verified-note-body">
              <span className="verified-note-kicker">
                <span className="verified-note-dot" aria-hidden="true" />
                Nota da redação · Conteúdo verificado
              </span>
              <p>
                Todas as informações deste site oficial foram verificadas e aprovadas pelo{" "}
                <b>Dr. e psicólogo Maurício</b>.
              </p>
            </div>
          </aside>

          <DoctorMessage city={city} />

          <h2 id="dormir-em-paz" className="center sec-title patient-title">
            Comentário da minha <span className="green">paciente número 1401</span>
          </h2>

          <div className="fb-comment">
            <img src={FB_COMMENT} alt="Comentário de cliente no Facebook sobre o Mulungu" loading="lazy" />
          </div>
        </div>
      </div>
    </section>
  )
}
