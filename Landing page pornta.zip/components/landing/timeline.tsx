const STEPS = [
  { period: "Dia 1 a 3", title: "A mente desacelera", desc: "Você deita e, pela primeira vez em muito tempo, os pensamentos param de girar. Adormecer fica mais fácil." },
  { period: "Dia 4 a 7", title: "Noites sem despertar", desc: "Os despertares de madrugada diminuem. Você acorda mais descansada, sem sensação de ressaca." },
  { period: "Semana 2 a 4", title: "O peito solta", desc: "O aperto no peito e a falta de ar aliviam. Ombros e mandíbula relaxam. O coração acelera menos." },
  { period: "Mês 2 a 6", title: "Você de volta", desc: "Sono profundo todas as noites, paciência, disposição e leveza. A ansiedade deixa de mandar na sua vida." },
]

export function Timeline() {
  return (
    <section className="timeline-compact-section anim in">
      <div className="wrap">
        <div className="timeline-compact-box">
          <div className="timeline-compact-header">
            <span className="timeline-sub-tag">Cronograma</span>
            <h2 className="timeline-compact-title">
              O que acontece desde o primeiro dia <span className="green">tomando Mulungu:</span>
            </h2>
          </div>
          <div className="timeline-compact-grid">
            {STEPS.map((s) => (
              <div key={s.period} className="timeline-compact-card">
                <div className="tc-step-num">{s.period}</div>
                <h4 className="tc-step-title">{s.title}</h4>
                <p className="tc-step-desc">{s.desc}</p>
              </div>
            ))}
          </div>
          <div className="timeline-compact-notice">
            <span>✓ A maioria das clientes relata noites mais tranquilas já na primeira semana.</span>
          </div>
        </div>
      </div>
    </section>
  )
}
