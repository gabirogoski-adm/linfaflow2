"use client"

import { useEffect, useRef, useState } from "react"
import { BUYER_NAMES, CITIES, KITS, PROOF_IMAGES, cdnImg, type KitOffer } from "@/lib/mulungu-data"
import { scrollToOffers } from "@/lib/scroll"
import type { ToastCity } from "@/lib/br-cities"

export function StickyBar({ show, selectedKit }: { show: boolean; selectedKit: KitOffer }) {
  return (
    <div className={`stickybar ${show ? "show" : ""}`}>
      <div className="info">
        Mulungu Silvestre Puro &nbsp;
        <span className="oldp">{selectedKit.oldPrice}</span>
        <span className="newp">{selectedKit.newPrice}</span>
      </div>
      <a href="#offers" className="js-buy" onClick={scrollToOffers}>
        Escolher Oferta →
      </a>
    </div>
  )
}

export function StockBadge({ stock, lastDeduction }: { stock: number; lastDeduction: number | null }) {
  const [animating, setAnimating] = useState(false)

  useEffect(() => {
    if (lastDeduction === null) return
    setAnimating(true)
    const t = setTimeout(() => setAnimating(false), 1400)
    return () => clearTimeout(t)
  }, [stock, lastDeduction])

  return (
    <div className="stock-ball-wrapper" title={`${stock} unidades restantes em estoque`}>
      <div className={`stock-ball ${animating ? "stock-ball-pulse" : ""}`}>
        <span className="stock-ball-label">Restam:</span>
        <div className="stock-ball-number-row">
          <span className="stock-ball-count">{stock}</span>
          <span className="stock-ball-unit">unid.</span>
        </div>
        {animating && lastDeduction !== null && <span className="stock-ball-diff">-{lastDeduction}</span>}
      </div>
    </div>
  )
}

const DELAYS = [9000, 5000, 12000, 7000, 10000, 6000]

const MALE_PHOTOS = ["carrossel_5.", "carrossel_4.", "carrossel_9."]
const MALE_NAMES = ["José Carlos", "Antônio", "Roberto"]

const BUYERS = (() => {
  let female = 0
  let male = 0
  return PROOF_IMAGES.map((photo) => {
    const isMale = MALE_PHOTOS.some((key) => photo.includes(key))
    const name = isMale
      ? MALE_NAMES[male++ % MALE_NAMES.length]
      : BUYER_NAMES[female++ % BUYER_NAMES.length]
    return { photo, name }
  })
})()

export function SalesToast({
  stock,
  onSale,
  cities,
}: {
  stock: number
  onSale: (bottles: number) => void
  cities: ToastCity[]
}) {
  const [visible, setVisible] = useState(false)
  const [index, setIndex] = useState(0)
  const cycleRef = useRef(0)
  const stockRef = useRef(stock)
  const onSaleRef = useRef(onSale)
  stockRef.current = stock
  onSaleRef.current = onSale

  useEffect(() => {
    let hideTimer: ReturnType<typeof setTimeout>
    let nextTimer: ReturnType<typeof setTimeout>

    const cycle = () => {
      if (stockRef.current <= 12) return
      const i = cycleRef.current
      setIndex(i)
      setVisible(true)
      onSaleRef.current(KITS[i % KITS.length].bottles)
      hideTimer = setTimeout(() => {
        setVisible(false)
        cycleRef.current += 1
        nextTimer = setTimeout(cycle, DELAYS[cycleRef.current % DELAYS.length])
      }, 5000)
    }

    nextTimer = setTimeout(cycle, 6000)
    return () => {
      clearTimeout(hideTimer)
      clearTimeout(nextTimer)
    }
  }, [])

  const kit = KITS[index % KITS.length]
  const cityList = cities.length > 0 ? cities : CITIES
  const city = cityList[index % cityList.length]
  const buyer = BUYERS[index % BUYERS.length]
  const name = buyer.name
  const minutes = (index % 9) + 2

  return (
    <div className={`salespop ${visible ? "show" : ""}`} role="status" aria-live="polite">
      <button type="button" className="salespop-close" onClick={() => setVisible(false)} aria-label="Fechar notificação">
        ✕
      </button>
      <div className="av">
        <img src={cdnImg(buyer.photo, 96)} alt="" width={44} height={44} decoding="async" />
      </div>
      <div className="txt" style={{ paddingRight: 14 }}>
        {name} de{" "}
        <b className="city-highlight">
          {city.city}
          {city.state ? `-${city.state}` : ""}
        </b>{" "}
        acabou de garantir o{" "}
        <span style={{ color: "var(--verde-esc)", fontWeight: 700 }}>{kit.title.split(" · ")[0]}</span>
        <small>há {minutes} minutos · envio rastreado ✓</small>
      </div>
    </div>
  )
}
