const METHODS = [
  { label: "VISA", logo: "/pay/visa.svg" },
  { label: "MASTER", logo: "/pay/mastercard.svg" },
  { label: "ELO", logo: "/pay/elo.svg" },
  { label: "AMEX", logo: "/pay/amex.svg" },
  { label: "HIPER", logo: "/pay/hipercard.svg" },
  { label: "PIX", logo: "/pay/pix.svg" },
  { label: "BOLETO", logo: "/pay/boleto.svg" },
]

export function PaymentBadges({ dark = false, withHiper = false }: { dark?: boolean; withHiper?: boolean }) {
  const methods = withHiper ? METHODS : METHODS.filter((m) => m.label !== "HIPER")
  return (
    <ul className={`paygrid ${dark ? "paygrid-dark" : ""}`} aria-label="Formas de pagamento">
      {methods.map((m) => (
        <li key={m.label} className="paygrid-item">
          <span className="paygrid-txt">{m.label}</span>
          <img src={m.logo || "/placeholder.svg"} alt={m.label} className="paygrid-logo" loading="lazy" />
        </li>
      ))}
    </ul>
  )
}
