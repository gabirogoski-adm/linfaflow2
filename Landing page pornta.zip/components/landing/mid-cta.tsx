"use client"

import { scrollToOffers } from "@/lib/scroll"

export function MidCta({ title, text, button }: { title: string; text: string; button: string }) {
  return (
    <section className="sec-white mid-cta-section">
      <div className="wrap">
        <div className="mid-cta">
          <p className="mid-cta-title">{title}</p>
          <p className="mid-cta-text">{text}</p>
          <a href="#escolha-seu-kit" onClick={scrollToOffers} className="reveal-cta-btn">
            {button}
          </a>
        </div>
      </div>
    </section>
  )
}
