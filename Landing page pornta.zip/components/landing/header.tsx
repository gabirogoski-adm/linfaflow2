const KEYWORDS = [
  "SONO PROFUNDO E REPARADOR",
  "FIM DA ANSIEDADE",
  "MENTE SILENCIADA",
  "ADEUS APERTO NO PEITO",
  "100% NATURAL E SEM VÍCIO",
  "ACORDE SEM RESSACA",
  "+87 MIL MULHERES DORMINDO EM PAZ",
]

export function Header() {
  return (
    <>
      <header>
        <div className="header-in">
          <div style={{ gridColumn: 2, display: "flex", alignItems: "center", gap: 8 }}>
            <div className="logo" style={{ userSelect: "none" }}>
              Mulungu<span style={{ color: "var(--laranja)", fontWeight: 800 }}>Puro</span>
            </div>
          </div>
          <div className="trust-mini">
            <div>
              <span className="dot"></span> Compra 100% segura
            </div>
            <div>Frete grátis</div>
            <div>Garantia 180 dias</div>
          </div>
        </div>
      </header>

      <div className="kwbar" aria-hidden="true">
        <div className="track">
          {[...KEYWORDS, ...KEYWORDS].map((k, i) => (
            <span key={i}>{k}</span>
          ))}
        </div>
      </div>
    </>
  )
}
