export const PRODUCT_IMAGE = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-IFJpM9t0R14MX3rt6E04GrfhIQ9b1G.png"
export const HERO_CUSTOMER_IMAGE = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-BXr7ockAHUa9Fv3ciMxtBoYtVMdVYh.png"
export const FLOW_INFO_IMAGE = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-r7g6utHxg25zXnyTe0fPjywQQNvvbu.png"
export const RITUAL_SCOOP_IMAGE = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-ePakmD7HfRODYqyX2xP88mpGL1Hkhi.png"
export const RITUAL_WATER_IMAGE = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-yrXzlev8abrPry9tcFoPypQGGIxAqP.png"
export const COMPARE_IMAGE = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-NSZ01GSXWkAz9zVsSKL53t9URIKBbU.png"

export const keywords = ["BARRIGA DESINCHADA EM 14 DIAS", "APOIO À DRENAGEM LINFÁTICA", "ELIMINAÇÃO DE LÍQUIDOS", "EMAGRECIMENTO", "4 EXTRATOS VEGETAIS", "REGULARIZADO NA ANVISA", "FRETE GRÁTIS", "GARANTIA DE 30 DIAS"]

export const benefits = ["Ajuda a reduzir o inchaço e a eliminar líquidos retidos", "Apoio à drenagem linfática natural", "Fórmula com 4 extratos vegetais", "Pó solúvel para incluir mais água na rotina", "Sabor neutro", "150 g por pote"]

export const miniFaq = [
  { question: "Como tomo e qual é o sabor?", answer: "Dissolva 1 scoop em 200 ml de água, seguindo as instruções do rótulo. O sabor é neutro." },
  { question: "Em quanto tempo posso notar diferença?", answer: "Cada organismo responde de um jeito. Não há um prazo único ou resultado garantido; mantenha uma rotina equilibrada e observe como você se sente." },
  { question: "E se não funcionar para mim?", answer: "A compra inclui garantia de 30 dias. Consulte os termos da oferta para conhecer as condições de solicitação do reembolso." },
  { question: "Quanto tempo leva para chegar?", answer: "O prazo de entrega e o rastreio são informados na finalização da compra e variam conforme o seu CEP." },
]

export const quizQuestions = [
  { area: "Inchaço", short: "Olhos inchados", resultText: "Você marcou inchaço ao redor dos olhos ou do rosto ao acordar.", question: "Você acorda com o rosto ou os olhos visivelmente inchados?", image: "/images/quiz/quiz-rosto.png", imageAlt: "Rosto em close com pálpebras e bolsas sob os olhos visivelmente inchadas" },
  { area: "Inchaço", short: "Barriga estufada", resultText: "Você marcou a barriga estufada e a roupa apertando ao longo do dia.", question: "Sua barriga fica visivelmente estufada e a roupa aperta ao longo do dia?", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFjIlop7j3hRCrbFYE00Eo9J0FmFIiSPJ4unLbj8ht-Q&s=10", imageAlt: "Imagem de referência mostrando pés inchados" },
  { area: "Circulação", short: "Pernas pesadas", resultText: "Você marcou pernas pesadas e inchadas depois de passar o dia em pé.", question: "Suas pernas ficam inchadas e pesadas depois de um dia em pé?", image: "/images/quiz/quiz-pernas.png", imageAlt: "Pernas com inchaço visível nas panturrilhas e nos tornozelos" },
  { area: "Inchaço", short: "Marca da meia", resultText: "Você marcou marcas fundas da meia junto de inchaço no tornozelo.", question: "Você percebe o tornozelo inchado ou a meia deixa uma marca funda na pele?", image: "/images/quiz/quiz-marcas.png", imageAlt: "Close de tornozelo inchado com uma marca funda deixada pela meia" },
  { area: "Circulação", short: "Muitas horas sentada(o)", resultText: "Você marcou inchaço depois de longos períodos sentada(o) ou em pé.", question: "Depois de muitas horas sentada(o) ou em pé, seus tornozelos ficam inchados?", image: "https://encrypted-tbn0.gstatic.com/images?q=ANd9GcRhTQhx7kuzfcXrTD59L_x_EhyMvhYIMWMaQ6u793-7wjL_iR-UKw_dNBcY&s=10", imageAlt: "Imagem de referência mostrando um abdômen estufado" },
  { area: "Inchaço", short: "Roupa apertada", resultText: "Você marcou a roupa apertando a cintura no fim do dia.", question: "À noite, a barriga estufada faz a roupa apertar na cintura?", image: "https://areademulher.r7.com/wp-content/uploads/2021/03/barriga-inchada-principais-causas-e-como-tratar-e1616813125800.jpg", imageAlt: "Pessoa com o cós do jeans apertado sobre a barriga" },
  { area: "Circulação", short: "Sapatos apertados", resultText: "Você marcou pés inchados e sapatos apertados no fim do dia.", question: "No fim do dia, seus pés incham e os sapatos ficam apertados?", image: "/images/quiz/quiz-leveza.png", imageAlt: "Pés inchados pressionando as tiras e o cabedal de sapatos apertados" },
]

export const steps = [
  { title: "A rotina pesa no corpo.", text: "Longos períodos sentada(o), poucas pausas e hábitos do dia a dia deixam o inchaço e o cansaço em evidência." },
  { title: "O inchaço merece atenção.", text: "Rosto, barriga e pernas mostram sinais diferentes. Uma avaliação profissional investiga a causa." },
  { title: "Apoio para o fluxo linfático.", text: "LinfaFlow reúne extratos vegetais e foi pensado para apoiar o fluxo linfático natural como parte de uma rotina equilibrada." },
]

export const ingredients = [
  { name: "Chá verde", text: "Apoia o metabolismo e a queima de gordura, auxilia na eliminação de líquidos e oferece compostos antioxidantes.", image: "/images/ingredients/green-tea.png", imageAlt: "Folhas de chá verde sobre superfície clara" },
  { name: "Hibisco", text: "Com ação diurética, auxilia na eliminação de líquidos retidos e contribui para uma sensação de leveza.", image: "/images/ingredients/hibiscus.png", imageAlt: "Flores vermelhas de hibisco e pétalas secas" },
  { name: "Gengibre", text: "Ajuda no gasto calórico e na circulação, além de contribuir para o conforto abdominal.", image: "/images/ingredients/ginger.png", imageAlt: "Raiz fresca de gengibre com fatias" },
  { name: "Chá branco", text: "Fonte de antioxidantes, complementa a combinação de extratos para apoiar a composição corporal.", image: "/images/ingredients/white-tea.png", imageAlt: "Brotos claros e folhas de chá branco" },
]

export const timeline = [
  { period: "Comece no seu ritmo", title: "Inclua o cuidado", text: "Siga a dose e o modo de uso do rótulo, junto a uma rotina equilibrada." },
  { period: "Dia a dia", title: "Mantenha a constância", text: "Escolha um horário e transforme o cuidado em um hábito possível." },
  { period: "Sem prazo universal", title: "Observe como se sente", text: "A percepção de inchaço e leveza muda de pessoa para pessoa." },
  { period: "Bem-estar contínuo", title: "Cuide do conjunto", text: "Hidratação, movimento e alimentação equilibrada também fazem parte da rotina." },
]

export const kits = [
  { id: "1", label: "Para experimentar", name: "1 POTE", subtitle: "1 mês · Kit individual", unit: "119,90", total: "119,90", installments: "12x de R$ 12,04", daily: "Menos de R$ 4,00 por dia", bonus: "1 e-book", image: PRODUCT_IMAGE },
  { id: "3", label: "Mais vendido", name: "LEVE 3, PAGUE 2", subtitle: "3 meses · Mais unidades no kit", unit: "79,93", total: "239,80", installments: "12x de R$ 24,00", daily: "Menos de R$ 2,70 por dia", bonus: "3 e-books + checklist", image: PRODUCT_IMAGE, recommended: true },
  { id: "5", label: "Maior economia", name: "LEVE 5, PAGUE 3", subtitle: "5 meses · Maior economia por pote", unit: "71,94", total: "359,70", installments: "12x de R$ 36,11", daily: "Menos de R$ 2,40 por dia", bonus: "5 e-books + checklist", image: PRODUCT_IMAGE },
]

export const ebooks = ["Protocolo Drenagem Profunda", "Movimento em Casa", "Desinchar com Firmeza", "Comer Sem Culpa", "O Ritual da Noite"]

export const faqs = [
  { question: "Como preparo o LinfaFlow?", answer: "Misture a porção indicada no rótulo em água. Confira na embalagem a medida e a quantidade recomendadas." },
  { question: "Em quanto tempo aparecem resultados?", answer: "Não existe prazo universal nem resultado garantido. Experiências individuais variam e não substituem avaliação profissional." },
  { question: "O quiz identifica a causa do inchaço?", answer: "Não. O quiz apenas organiza suas respostas; inchaço persistente ou preocupante deve ser avaliado por um profissional de saúde." },
  { question: "Quem deve consultar um profissional antes de usar?", answer: "Gestantes, lactantes, pessoas em tratamento ou que usam medicamentos devem consultar um profissional e seguir as orientações do rótulo." },
]

export const RATING_SUMMARY: { nota: string; total: string; barras: { estrelas: number; pct: string; qtd: string }[] } | null = null
export const REVIEWS_CARROSSEL: { nome: string; idade?: number; quando: string; estrelas: number; titulo: string; texto: string; foto?: string }[] = []
export const REVIEWS: { nome: string; texto: string; data: string; estrelas: number; foto?: string }[] = [
  { nome: "Roberto S.", texto: "Jurava que era gordura na barriga. 4 meses de DrenaLinf seguindo o protocolo, e a calça 48 que estava encostada voltou a fechar. Hoje uso 44 com folga.", data: "há 1 mês · Avaliação verificada pelo Google", estrelas: 5 },
  { nome: "Maria K.", texto: "Acordava com o rosto inchado mesmo dormindo bem, tinha vergonha de me olhar no espelho de manhã. Em 2 semanas de DrenaLinf isso mudou. Foi uma bênção.", data: "há 2 semanas · Avaliação verificada pelo Google", estrelas: 5 },
  { nome: "Renata M.", texto: "Já me falaram que era gordura, lipedema, celulite, idade... tudo menos retenção. Eu tinha me conformado. No terceiro mês de DrenaLinf minhas pernas afinaram visivelmente. Era líquido parado esse tempo todo.", data: "há 3 semanas · Avaliação verificada pelo Google", estrelas: 5 },
]
export const PROOF_IMAGES: string[] = []
export const VIDEO_DEPOIMENTO: string | null = null
export const CONTATO = { telefone: "", email: "", horario: "Seg a Sex, 09h às 18h", razaoSocial: "", cnpj: "" }
export const SELOS_CONFIANCA = ["Regularizado na Anvisa", "Produzido no Brasil", "Testado e aprovado", "+60.000 clientes satisfeitos", "Fórmula natural · 4 extratos", "Vegano", "Sem álcool", "Sem glúten", "Sem açúcar"]
